from pathlib import Path
import json
import numpy as np
import pandas as pd

OUT=Path(__file__).resolve().parent
def table(df):
    def f(x):return f'{x:.8f}' if isinstance(x,(float,np.floating)) else str(x)
    return '\n'.join(['| '+' | '.join(df.columns)+' |','| '+' | '.join(['---']*len(df.columns))+' |']+['| '+' | '.join(f(v) for v in r)+' |' for r in df.itertuples(index=False,name=None)])

ret=pd.read_csv(OUT/'source_accuracy_retention.csv')
ret=ret[['version','variant','fold','correct10','correct4','acc10','acc4','delta_acc10_pp','delta_acc4_pp']].copy()
ret['acc10']*=100;ret['acc4']*=100
sens=pd.read_csv(OUT/'remove_exact_duplicates_sensitivity.csv');sens=sens[(sens.scope=='remove_31_exact_train_query_duplicates_only')&((sens.version=='original')|((sens.variant=='v0')&(sens.version.isin(['v1','conservative']))))]
sens=sens[['version','fold','n','correct10','correct4','acc10','acc4','delta_acc10_pp','delta_acc4_pp']].copy();sens['acc10']*=100;sens['acc4']*=100
risks=[
 dict(id='S1',classification='明确跨划分输入共享',finding='原train输入中的健康reference包括6690个test-query ID和13425个val-query ID；健康身份参与reference选择',evidence='source_reference_cross_split.csv',scope='继承MBHM原协议；不是local代码把目标故障标签喂入模型'),
 dict(id='S2',classification='明确完全重复',finding='全源600组1504行DCN完全相同；148组299行跨划分；31个test和92个val query与train query逐字节相同',evidence='source_train_eval_duplicate_counts.json; source_cross_split_exact_duplicate_rows.json',scope='已发布DCN输入层；不等于已经定位原始长录制来源'),
 dict(id='S3',classification='明确同工况共享',finding='257/257个test condition在train出现，原split为query序号模10',evidence='source_split_statistics.csv',scope='不支持未见condition泛化；是否定义为泄漏取决于任务声明'),
 dict(id='S4',classification='明确回放参考共享',finding='1174 train query的3522对输入含340次test reference、715次val reference；另14次self-reference',evidence='source_replay_reference_summary.csv',scope='query train-only成立；原始信号完全train-only不成立'),
 dict(id='S5',classification='明确测试重复使用',finding='保守版本约束由查看v1 old-test子数据集退化后加强；之后再次用同一test回归',evidence='retention_alignment_20260922/scripts/refine_retention.py:3',scope='各轮内部候选仍按train+val排序，但不能称第二轮新盲测'),
 dict(id='S6',classification='未知原始派生边界',finding='无原始录制ID、实体序列号或窗口起止样本；DCN字节不同不能排除原始时间重叠/相邻同实体窗口',evidence='preliminary_summary.json; source_duplicate_summary.json',scope='不能给原始数据实体独立性保证'),
 dict(id='L1',classification='明确实体共享',finding='同类两次录制为同一轴承，同一主电机/台架；两fold只能称录制留出',evidence='local_split_membership.json; 用户确认',scope='不自动等于录制分类任务代码泄漏，但不符合新轴承/新电机留出'),
 dict(id='L2',classification='未发现直接本地划分泄漏',finding='train/test bag和窗口行不相交；同一配对contact/radar同步留出；外部样本未进入拟合',evidence='local_split_membership.json',scope='仅所审计当前两fold实现，不扩展到旧MBHM'),
 dict(id='L3',classification='未发现scaler目标拟合',finding='source scaler、contact/radar学生scaler均可由训练行独立精确重建',evidence='scaler_reconstruction.csv',scope='当前代码和保存模型；不是数据实体独立证明'),
 dict(id='L4',classification='未发现本地exact复制',finding='24 NPZ文件、88接触窗口、614雷达窗口和12280导出IQ帧没有exact重复；单文件帧区间无交叠',evidence='local_exact_duplicates.json; local_file_hashes.csv',scope='原始DAT/bin未在本地，仍不能追溯跨文件原始样本/近重复'),
 dict(id='L5',classification='明确几何混杂',finding='外圈/keep保留约0.884m距离门而实际40余cm；类别与几何关联',evidence='前轮radar/metadata.csv及用户距离确认',scope='质量/混杂问题；不是证明代码直接读取测试标签'),
 dict(id='L6',classification='明确额外校准共享',finding='local_healthy_reference辅助实验用另一个波特率normal录制作reference；其normal也在8个query中',evidence='preprocessing/local_healthy_reference/reference_manifest.json',scope='不可混入主零校准CV；当前主head未使用该辅助特征'),
 dict(id='L7',classification='明确开发集重复评估',finding='同8个本地录制与bigNormal已在多轮方法设计/错误分析中反复查看',evidence='前轮posthoc周期归一化及本轮保守开发过程',scope='未发现目标标签进入当前loss，不代表完全未接触的最终盲测')]
pd.DataFrame(risks).to_csv(OUT/'finding_register.csv',index=False)
writeup='''# Source retention与本地跨模态数据泄露审计

2026-09-22；conda `m2vllm`。本次只读检查既有数据、代码、划分和模型，不重新训练，不改原NPZ、权重或结果。

## 主结论：哪些问题确实存在

**发现旧源数据中31个test query的24000维DCN与train query逐字节相同。** 全135,516条已发布DCN扫描得到600组完全重复、涉及1,504行；其中148组跨train/val/test、涉及299行（HIT 144组、PU 4组）。另有92个val query与train query完全相同。跨划分重复组没有标签冲突。这里比较的是模型实际读取的派生DCN输入，足以否定严格的“测试输入全部未见”；尚不能据此定位原始采集文件为何重复。

此外，旧协议允许train query使用val/test query的健康信号作reference。原train中有25,789次reference引用来自test，涉及6,690个不同test-query ID；51,647次来自val，涉及13,425个不同ID。**只删除上述31个重复test query，不能清除健康reference跨集合、同condition共享和未知实体关系。**

本地两个波特率录制留出实现中，没有发现测试窗口直接进入训练采样、scaler拟合、teacher训练原型或候选排序；但同类两录制明确来自同一轴承，且来自同一台架/电机。这只能支持录制留出，不能称新轴承或新电机留出。外圈错误ROI、类别与采集条件相关是另一个明确的质量/混杂问题。

旧源协议的**同口径前后性能回归比较仍有意义**，可以说“在既有回归基准上下降多少”。不能再把其中约99%的绝对值称为严格独立源测试泛化。保守版本又使用了已经查看过的old-test，属于开发后的重复回归验证，不是新盲测。

## 1. 更正前轮“未发现泄漏”的范围

[前轮最终审查](/home/huangyating/anomaly_detection/four_class_chain_20260922/audit/final_result_review.md) 中的“未发现实现层面的目标数据泄漏”仅适用于当时本地bag划分、训练索引、scaler和结果计数，**不能推广到继承的MBHM原始训练/参考协议**。本轮已发现其跨集合reference和完全重复DCN，因此当前总体结论不能写成“整个链路无数据泄漏”。

“共享同台架/同轴承”“训练使用健康校准reference”“完全复制query”“查看test后重设计协议”也应分开：它们对应不同任务边界，不应全都混成一种实现bug或笼统视为相同严重程度。

## 2. 原源协议：query ID互斥，但模型输入不完全互斥

原`dataset.json`含85,955 train、24,558 val、12,279 test query，每个query有3个健康reference。查询ID本身不跨划分；划分却是按eligible query顺序模10的7/2/1，并非原始录制/轴承/电机分组。同condition没有健康reference的12,724条数据未进入这个回归基准。

所有257个test condition都在train出现。metadata的condition包含来源、轴承型号code、channel、rpm、load，这里没有原始长录制ID、实体序列号、原始起止样本字段；HDF5只有`vibration[135516,24000]`，文件/数据集attrs为空。因此不能从这些派生资产证明跨原始录制、跨轴承实体或无重叠时间切片。

reference选择使用同condition的所有健康行，不限制在train，且有放回抽样；健康query可抽到自己。原train/val/test分别有549/166/78对self-reference。这是明确的参考信息共享，不能解释为严格train-only原始信号隔离。在声明“已知健康校准”的任务中可以规定独立参考池，但当前参考池与评价query重叠，并未实行这种隔离。

[原协议实现](/home/huangyating/BearLLM/scripts/evaluate_mbhm.py:59)；[跨集合参考计数](source_reference_cross_split.csv)；[划分与condition计数](source_split_statistics.csv)。

### 当前回放也继承了参考共享

只从train query抽了1,174条回放，这一点成立；每条3个reference，共3,522对。其参考来源为：

| reference原query划分 | 引用次数 | 不同reference ID数 |
|---|---:|---:|
| train | 2,467 | 2,250 |
| val | 715 | 656 |
| test | 340 | 296 |

**296/656是不同ID数，不是引用次数。** 回放有14对self-reference；另有2个test query（12991、14081）的DCN与所抽train回放query完全相同。故“回放query只来自train”正确，“回放输入信号完全不含val/test”错误。健康身份本身也参与参考选择。

健康reference共享不等于把每个test故障query的真标签直接加入训练CE，但它使严格独立输入测试前提不成立。旧模型与新模型采用同一继承协议比较，可作回归；不能假定此共享对绝对准确率没有影响，也不能只据共享数量推导影响幅度。

## 3. 原数据重复：本次新增的全量证据

对全部135,516条float32×24,000 DCN分别做SHA-256，没有只抽样。600组重复共1,504行，148组跨划分共299行。其中跨train/val的组90、跨train/test的组30、跨val/test的组28；31个test query对应30组，因为组中可能有多个test query。

例如HIT的query12513与12621字节相同，前者train、后者test，均健康。完整行hash、组内ID、split、source、label均已落盘：[全行hash](source_dcn_row_hashes.csv)、[跨划分重复](source_cross_split_exact_duplicate_rows.json)、[与train相同的eval query](source_eval_queries_identical_to_train.csv)。

未发现标签冲突并不令重复合法化；它只是说明不是同一输入不同标签导致的矛盾。反过来，SHA不同也不证明原始长录制独立：相邻或重叠原始窗口通常不会逐字节相同。当前源资产缺少溯源信息，不能完成这一更强审计。

## 4. Head选择、测试集复用与可证范围

v1回放CE/KD只采`cache.split==train`的query-reference特征；source scaler也由该train回放重建。local CE只采本折训练录制。候选基于source val约束与local TRAIN文件F1/CE排序，未把local heldout分数或新head的source test分数写入该排序规则。

本次对全部9个v1选择和2个保守选择重新执行排序规则，11个均精确复现所选lambda/step；训练脚本SHA与当时completion记录相同。[候选选择复核](head_selection_rule_recheck.csv)；[完整性核验](selection_and_integrity.json)。

需要区分：v1程序开始时确实读取了原test基线并用于报告，因此不能说test数据从未被加载；准确说法是候选训练/排序未用新head的test结果。选定并写入`selection_before_test.json`后再算新head test得分。[v1选择代码](/home/huangyating/anomaly_detection/retention_alignment_20260922/scripts/train_retained_head.py:128)、[写选择后测试](/home/huangyating/anomaly_detection/retention_alignment_20260922/scripts/train_retained_head.py:146)。

保守第2轮是在查看v1某些source-test子集下降超过.5pp后，才加强逐source约束。它内部仍按source-val选lambda/step，但研发决策已受到第一轮test反馈。代码本身也明确写了`second development iteration after v1 subgroup review`和`source_test_is_reused_regression_not_new_blind_test`。[保守迭代声明](/home/huangyating/anomaly_detection/retention_alignment_20260922/scripts/refine_retention.py:3)。所以“未直接用test选该轮checkpoint”与“整个研发过程未看test”不是一回事。

同样，本地8份录制和bigNormal已在多轮错误分析、DC/参考敏感性、周期归一化、head/蒸馏设计中反复查看。当前代码内无直接目标泄漏，不会使这些数据重新成为未接触的最终盲测。v1/all_known与保守all_known的本地8/8也只是全量本地训练录制的拟合结果。

## 5. 本地数据：核查通过的实现项及其边界

两个fold的contact/radar使用同一bag划分，train/test bag与窗口行无交集；外部keep/bigNormal均未进入scaler、teacher原型、监督训练或候选选择。每类两录制同轴承为用户已确认事实，因此只能说同轴承的不同录制留出。metadata中的实体字段为空不能反过来当作实体不同的证据。

独立重建训练统计的结果：source head mean/scale、学生contact mean/scale、学生radar mean/scale与保存值最大误差均为0。[Scaler核查](scaler_reconstruction.csv)。模型虽把全部数组加载到内存、也对test调用`transform`，这本身不等于fit泄漏；训练采样池只含train bag，雷达网络使用逐样本LayerNorm，接触式FCN为eval模式且BN缓冲区冻结。[contact/radar scaler及采样](/home/huangyating/anomaly_detection/retention_alignment_20260922/radar/train_shared_head.py:93)。

本地24个NPZ与前轮输入manifest哈希全部一致。24个文件无整文件SHA重复；88个接触raw_xyz窗口、614个雷达IQ窗口和12,280个已导出IQ帧无完全重复；每个雷达文件的20帧窗口区间不重叠。同一录制整体在一折内只属于一个集合，故同文件帧没有跨fold内train/test复用。两个互补fold会交换数据角色，这是交叉验证本身，不应把多个fold当作新独立录制。

本地264个接触式轴DCN与全部源DCN也没有exact相同。以上均只是字节级检查：原DAT/bin未在此位置可用，接触式还缺精确包时间，无法认证跨文件原始时间段不重叠、物理录制独立或没有近重复。[局部重复摘要](preliminary_summary.json)。

### 特征提取没有发现整测试集合拟合，但有校准范围

接触式DC去除、DCT和能量归一化按每个1秒窗口执行，没有拟合全测试文件均值/方差。主teacher的9个正常参考固定来自MBHM train健康query（本次重新核验），不来自本地test-normal、bigNormal或query自身；但工况并不匹配本地，是协议偏差，不能只因train-only就说参考合理。

雷达距离单元从**该录制开头3帧**的能量峰选定，并不是用整个测试文件、故障标签或测试集最优分类分数选门。后续幅度尺度由各自2秒窗口估计，静态量逐帧去除，频谱归一化逐窗口，固定频带均值/空间median没有跨录制拟合。[range与窗口处理](/home/huangyating/anomaly_detection/four_class_preprocessing_20260921/preprocess.py:192)。这属于录制内无标签校准，报告中应说明；不能拿它支持“无需启动校准”或比完整窗口更早的在线预测。

特征代码没有按故障标签选择频带、距离门或axis。标签用于训练集监督、contrast同类正例及事后计分，这与把test真值作为推理输入不同。类别与错误距离门相关、简单幅度基线满分则提示采集条件捷径风险，**不是直接证明模型使用了捷径或因果机制**；需要固定正确ROI、随机顺序、重新安装和条件平衡对照。

### 不要混入另一个local-normal辅助实验

`local_healthy_reference`曾固定取相反波特率的正常录制作参考；它不使用query自己的录制，但正常reference也属于8个被评价query录制之一，可能跨原CV边界提供额外已知正常信息。它是单独声明的额外健康校准实验，不能合入主零本地校准CV或声称严格train-only local reference。[辅助实验协议](/home/huangyating/anomaly_detection/retention_alignment_20260922/preprocessing/local_healthy_reference_check.py:13)。当前主v0/no-demean共享头与雷达学生读取的是external-reference variants，没有读取该辅助特征。

## 6. 原源准确率下降的精确值

主口径保持原协议：每个query三个reference各自softmax后平均；n=12,279。原十类为12,140/12,279=98.86798599%，原四类为12,163/12,279=99.05529766%。表中acc为百分数，delta为相对原模型的**百分点**；负数表示下降。

RETENTION_TABLE

v1两方向和保守all_known均满足全局.5pp回归门槛；v1较松all_known虽全局达标，部分source子集曾下降超过.5pp，促成保守迭代。保守版本在已重复使用的source test每个source十/四类也通过门槛。它们都是在上述继承协议下的回归事实，不是无泄露盲测性能保证。

### 仅删31条完全重复query的只读敏感性

无需训练，只去掉与原train query exact相同的31条test query，余12,248条，得到：

SENSITIVITY_TABLE

这31条均被旧模型和表中模型正确分类，删除后分母减少使accuracy略降。变化小**不等于泄露可以忽略**，因为尚未去掉6,690个被原train当健康reference读取的test-query ID，也没有处理同condition/实体/原始时间切片关系。这绝不是“去泄漏后干净测试”，不能替换报告主协议后如此命名。所有variant完整数据在 [remove_exact_duplicates_sensitivity.csv](remove_exact_duplicates_sensitivity.csv)。

## 7. 下一次可接受的干净验证需要什么

1. 源数据先取得原始录制/实体/窗口起止溯源，按实体或录制分组再切窗；exact重复组整体分配到一个split。若暂时只有DCN，至少按hash组隔离，但明确仍无法排除同原始录制近邻窗口。
2. 正常reference成为与所有query互斥的独立校准池，或者严格train-only池，禁止self-reference。若新工况允许额外健康校准，应把它作为明示任务条件，不混成零校准泛化。
3. 所有预处理参数、scaler、head选择和拒识阈值只用train/validation；冻结方法后启用尚未查看的新实体测试。当前反复评估过的old-test与8个本地录制继续只作回归/开发数据。
4. 本地补足每类多个轴承实体，按实体留出；两模态及该实体所有录制、帧、窗口和校准资料一起分组。跨电机评估另留整台电机，不把同电机不同波特率称跨结构。
5. 先以真实40余cm统一距离门重处理并记录ADC/采包溯源，再平衡故障类×转速×距离×环境×安装顺序。幅度/距离基线作为混杂探针保留，并用新的控制实验判断其是否是捷径。

## 8. 产物与核查范围

`audit_leakage.py`完成ID/参考/condition/scaler/本地frame检查及全源13.01GB DCN逐行hash；`augment_duplicate_audit.py`完成exact重复剔除敏感性；`verify_selection_and_integrity.py`复核11个模型选择和24个原输入hash。原始DAT/bin、原源长录制及实体溯源不在此次可核查资产范围，没有作出不存在泄露的全局保证。

[分类发现清单](finding_register.csv) · [全量审计事实](audit_summary.json) · [精确源性能CSV](source_accuracy_retention.csv)
'''
writeup=writeup.replace('RETENTION_TABLE',table(ret)).replace('SENSITIVITY_TABLE',table(sens))
(OUT/'数据泄露与评估边界审计.md').write_text(writeup)
summary=dict(scope='Read-only existing source and local evaluation protocol audit; no training or archive mutation',explicit_findings=[r for r in risks if r['classification'].startswith('明确')],no_direct_implementation_leak_found=[r for r in risks if r['classification'].startswith('未发现')],unknown=[r for r in risks if r['classification'].startswith('未知')],source_derived_data_only=True,source_original_test_is_strictly_independent=False,local_recording_split_is_bearing_entity_split=False,original_protocol_relative_regression_still_meaningful=True,prior_no_leakage_statement_scope_corrected=True,source_test_duplicate_removal_is_clean_protocol=False,raw_and_source_physical_provenance_not_available=True)
(OUT/'audit_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print('report and structured audit summary written')
