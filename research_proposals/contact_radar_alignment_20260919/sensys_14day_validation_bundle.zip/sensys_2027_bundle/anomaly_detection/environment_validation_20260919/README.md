# room/narrow 环境处理与验证

输入目录：`/home/huangyating/anomaly_detection/data9.18`。原始 bin 只读，派生结果在本目录。

研究问题是当前正常旋转/静止数据的环境鲁棒性。没有故障类、同步加速度或新电机群体，不能据此报告故障诊断或跨结构准确率。

## 当前任务与输出

- `results/watch_status.json`：实时上传/处理状态；`results/watch.log`：监测与运行日志。
- `results/parser_prefix_audit.csv`：上传期间读取固定前缀的格式合理性检查，不能代替完整数据验证。
- `环境泛化验证报告.md`：完整处理成功后生成，含真实表格、质量异常和四组彩图。
- `results/input_manifest.json` 与 `input_sha256.json`：处理快照和 SHA256。源端文件是否全部上传，仍应结合上传完成确认/源端哈希。
- `results/cross_environment_metrics.csv`、`file_predictions.csv`：源域选参、目标域逐文件评估明细。

监测规则为收到上传完成信号、本目录存在 `UPLOAD_COMPLETE.json`，并且至少 42 个 bin 连续 300 秒大小/mtime 不变。当前很多文件恰好停在上传块边界，因此单靠静默可能把网络暂停当上传结束。用户确认上传完成后，由助手写入信号文件，原进程即可自动开始。处理过程中有变化则重试，成功后继续监测至最长 12 小时；上传恢复会重新处理。若上传预计超过此时长，可重新运行监测命令。

## 复现命令

本次使用已有 `/home/huangyating/BearLLM/.venv/bin/python` 的科学计算依赖，只运行 CPU，不修改 BearLLM 仓库或训练任务。

```bash
python scripts/radar_environment.py self-check
python scripts/radar_environment.py audit-prefix
python -u scripts/watch_upload.py --quiet-seconds 300 --poll-seconds 20 --max-hours 12
```

输入完整且配置已核实时，也可顺序运行：

```bash
python scripts/radar_environment.py extract --conjugate
python scripts/evaluate_environment.py
```

当前解析器仅对应旧配置：256 ADC、4RX、192 chirp、100 ms 帧、500 μs chirp。新采 R2/R3 数据必须修改并记录解析参数，不能混入本目录后套用旧时序。

解析使用 2I/2Q 非交织 RX 布局；共轭方向由已知距离峰与 sampleSwap 语义检查决定，不按转速分类分数选格式。相邻三个 range-bin 来自补零后的谱，彼此相关；它们不是三个独立距离分辨单元或新增测量样本。

独立录制信息未确认前，结果按文件报告；同一次采集拆分文件应合并成同一 run。P1 只把目标 off 当噪声标定，不再用该记录测试 off 分类；参考几何异常时先排除该参考并披露。

完整研究路线见 [SenSys 投稿与 14 天验证](../../research_proposals/contact_radar_alignment_20260919/SenSys投稿与14天全链条验证.md)。
